import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertWaitlistSchema, 
  insertContactSchema, 
  insertQuoteSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);
  
  // API routes
  app.post("/api/waitlist", async (req, res) => {
    try {
      // Validate request data
      const result = insertWaitlistSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid request data", 
          errors: result.error.errors 
        });
      }
      
      // Create waitlist entry
      const entry = await storage.createWaitlistEntry(result.data);
      
      return res.status(201).json({
        message: "Successfully joined the waitlist",
        data: entry
      });
    } catch (error) {
      console.error("Error creating waitlist entry:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.post("/api/contact", async (req, res) => {
    try {
      // Validate request data
      const result = insertContactSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid request data", 
          errors: result.error.errors 
        });
      }
      
      // Create contact submission
      const submission = await storage.createContactSubmission(result.data);
      
      return res.status(201).json({
        message: "Contact form submitted successfully",
        data: submission
      });
    } catch (error) {
      console.error("Error creating contact submission:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.post("/api/quote", async (req, res) => {
    try {
      // Validate request data
      const result = insertQuoteSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid request data", 
          errors: result.error.errors 
        });
      }
      
      // Create quote request
      const quoteRequest = await storage.createQuoteRequest(result.data);
      
      return res.status(201).json({
        message: "Quote request submitted successfully",
        data: quoteRequest
      });
    } catch (error) {
      console.error("Error creating quote request:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  return httpServer;
}
