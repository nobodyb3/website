import { 
  users, 
  type User, 
  type InsertUser,
  waitlistEntries,
  type WaitlistEntry,
  type InsertWaitlistEntry,
  contactSubmissions,
  type ContactSubmission,
  type InsertContactSubmission,
  quoteRequests,
  type QuoteRequest,
  type InsertQuoteRequest
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Waitlist methods
  createWaitlistEntry(entry: InsertWaitlistEntry): Promise<WaitlistEntry>;
  getWaitlistEntries(): Promise<WaitlistEntry[]>;
  
  // Contact methods
  createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission>;
  getContactSubmissions(): Promise<ContactSubmission[]>;
  
  // Quote methods
  createQuoteRequest(request: InsertQuoteRequest): Promise<QuoteRequest>;
  getQuoteRequests(): Promise<QuoteRequest[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private waitlist: Map<number, WaitlistEntry>;
  private contacts: Map<number, ContactSubmission>;
  private quotes: Map<number, QuoteRequest>;
  
  private currentUserId: number;
  private currentWaitlistId: number;
  private currentContactId: number;
  private currentQuoteId: number;

  constructor() {
    this.users = new Map();
    this.waitlist = new Map();
    this.contacts = new Map();
    this.quotes = new Map();
    
    this.currentUserId = 1;
    this.currentWaitlistId = 1;
    this.currentContactId = 1;
    this.currentQuoteId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Waitlist methods
  async createWaitlistEntry(entry: InsertWaitlistEntry): Promise<WaitlistEntry> {
    const id = this.currentWaitlistId++;
    const createdAt = new Date();
    const waitlistEntry: WaitlistEntry = { ...entry, id, createdAt };
    this.waitlist.set(id, waitlistEntry);
    return waitlistEntry;
  }
  
  async getWaitlistEntries(): Promise<WaitlistEntry[]> {
    return Array.from(this.waitlist.values());
  }
  
  // Contact methods
  async createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission> {
    const id = this.currentContactId++;
    const createdAt = new Date();
    const contactSubmission: ContactSubmission = { ...submission, id, createdAt };
    this.contacts.set(id, contactSubmission);
    return contactSubmission;
  }
  
  async getContactSubmissions(): Promise<ContactSubmission[]> {
    return Array.from(this.contacts.values());
  }
  
  // Quote methods
  async createQuoteRequest(request: InsertQuoteRequest): Promise<QuoteRequest> {
    const id = this.currentQuoteId++;
    const createdAt = new Date();
    const quoteRequest: QuoteRequest = { ...request, id, createdAt };
    this.quotes.set(id, quoteRequest);
    return quoteRequest;
  }
  
  async getQuoteRequests(): Promise<QuoteRequest[]> {
    return Array.from(this.quotes.values());
  }
}

export const storage = new MemStorage();
