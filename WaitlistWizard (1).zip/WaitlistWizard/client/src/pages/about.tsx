import PageLayout from "@/components/layout/page-layout";
import AboutSection from "@/components/home/about-section";

export default function AboutPage() {
  return (
    <PageLayout>
      {/* Page header with banner image */}
      <div className="relative">
        <div className="h-64 md:h-80 bg-gradient-to-r from-[#8B0000]/90 to-[#613613]/90 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">About Us</h1>
            <p className="text-xl max-w-2xl mx-auto px-4">
              Learn about our commitment to quality, heritage, and sustainable premium beef production.
            </p>
          </div>
        </div>
      </div>
      
      {/* About content */}
      <AboutSection />
    </PageLayout>
  );
}