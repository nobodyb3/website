import { useState } from "react";
import PageLayout from "@/components/layout/page-layout";
import ProductsSection from "@/components/home/products-section";
import QuoteModal from "@/components/home/quote-modal";

export default function ProductsPage() {
  const [quoteModalOpen, setQuoteModalOpen] = useState(false);

  const openQuoteModal = () => {
    setQuoteModalOpen(true);
  };

  const closeQuoteModal = () => {
    setQuoteModalOpen(false);
  };

  return (
    <PageLayout>
      {/* Page header with banner image */}
      <div className="relative">
        <div className="h-64 md:h-80 bg-gradient-to-r from-[#8B0000]/90 to-[#613613]/90 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">Our Products</h1>
            <p className="text-xl max-w-2xl mx-auto px-4">
              Discover our premium beef products, known for their exceptional quality and flavor.
            </p>
          </div>
        </div>
      </div>
      
      {/* Products content */}
      <ProductsSection openQuoteModal={openQuoteModal} />

      {/* Quote modal specific to this page */}
      <QuoteModal 
        isOpen={quoteModalOpen} 
        onClose={closeQuoteModal} 
      />
    </PageLayout>
  );
}