import { useState } from "react";
import PageLayout from "@/components/layout/page-layout";
import HeroSection from "@/components/home/hero-section";
import AboutSection from "@/components/home/about-section";
import ProductsSection from "@/components/home/products-section";
import ProcessSection from "@/components/home/process-section";
import WhyUsSection from "@/components/home/why-us-section";
import GallerySection from "@/components/home/gallery-section";
import ContactSection from "@/components/home/contact-section";

export default function Home() {
  const [quoteModalOpen, setQuoteModalOpen] = useState(false);

  const openQuoteModal = () => {
    setQuoteModalOpen(true);
  };

  return (
    <PageLayout>
      <div className="mt-0 pt-0">
        <HeroSection openQuoteModal={openQuoteModal} />
        <AboutSection />
        <ProductsSection openQuoteModal={openQuoteModal} />
        <ProcessSection />
        <WhyUsSection />
        <GallerySection />
        <ContactSection />
      </div>
    </PageLayout>
  );
}
