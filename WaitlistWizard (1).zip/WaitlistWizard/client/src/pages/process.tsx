import PageLayout from "@/components/layout/page-layout";
import ProcessSection from "@/components/home/process-section";

export default function ProcessPage() {
  return (
    <PageLayout>
      {/* Page header with banner image */}
      <div className="relative">
        <div className="h-64 md:h-80 bg-gradient-to-r from-[#8B0000]/90 to-[#613613]/90 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">Our Process</h1>
            <p className="text-xl max-w-2xl mx-auto px-4">
              Learn about our meticulous process from breeding to distribution that ensures premium quality beef.
            </p>
          </div>
        </div>
      </div>
      
      {/* Process content */}
      <ProcessSection />
    </PageLayout>
  );
}