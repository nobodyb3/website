import PageLayout from "@/components/layout/page-layout";
import ContactSection from "@/components/home/contact-section";

export default function ContactPage() {
  return (
    <PageLayout>
      {/* Page header with banner image */}
      <div className="relative">
        <div className="h-64 md:h-80 bg-gradient-to-r from-[#8B0000]/90 to-[#613613]/90 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">Contact Us</h1>
            <p className="text-xl max-w-2xl mx-auto px-4">
              We'd love to hear from you. Reach out to discuss how our premium beef can meet your needs.
            </p>
          </div>
        </div>
      </div>
      
      {/* Contact content */}
      <ContactSection />
    </PageLayout>
  );
}