import { Award, Check, Truck, HandshakeIcon, Star } from "lucide-react";
import { features } from "@/lib/data";

export default function WhyUsSection() {
  const renderIcon = (iconName: string) => {
    switch(iconName) {
      case 'award':
        return <Award className="h-8 w-8" />;
      case 'certificate':
        return <Check className="h-8 w-8" />;
      case 'truck':
        return <Truck className="h-8 w-8" />;
      case 'handshake':
        return <HandshakeIcon className="h-8 w-8" />;
      default:
        return <Check className="h-8 w-8" />;
    }
  };

  return (
    <section id="why-us" className="py-20 bg-gradient-to-r from-[#8B0000] to-[#590000] text-white relative overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-serif font-bold">
            Why Choose <span className="text-[#D4AF37]">Us</span>
          </h2>
          <div className="w-24 h-1 bg-[#D4AF37] mx-auto my-4"></div>
          <p className="max-w-2xl mx-auto text-lg text-gray-200">
            What sets our premium beef exports apart from the competition.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature) => (
            <div 
              key={feature.id}
              className="bg-white bg-opacity-10 p-8 rounded-lg backdrop-filter backdrop-blur-sm hover:bg-opacity-15 hover:transform hover:scale-105 hover:shadow-xl transition-all duration-300 ease-in-out"
            >
              <div className="text-[#D4AF37] text-4xl mb-4">
                {renderIcon(feature.icon)}
              </div>
              <h3 className="text-xl font-serif font-bold mb-3">{feature.title}</h3>
              <p className="text-gray-200">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="bg-white bg-opacity-10 rounded-lg p-8 max-w-4xl mx-auto">
            <div className="flex items-center justify-center mb-6">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="text-[#D4AF37] h-6 w-6 mx-1 fill-current" />
              ))}
            </div>
            <blockquote className="text-xl italic mb-4">
              "Their premium beef exports have consistently exceeded our expectations in quality. The marbling and tenderness are unmatched in the industry."
            </blockquote>
            <div className="font-serif font-semibold">
              <span className="text-[#D4AF37]">John Anderson</span> — Executive Chef, Grand Plaza Hotel
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
