import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertWaitlistSchema } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

// Extend the schema with additional validation
const formSchema = insertWaitlistSchema.extend({
  email: z.string().email("Please enter a valid email address"),
});

type FormValues = z.infer<typeof formSchema>;

export default function WaitlistForm() {
  const { toast } = useToast();
  const [isSuccess, setIsSuccess] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
    },
  });

  const waitlistMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      const response = await apiRequest("POST", "/api/waitlist", values);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success!",
        description: "You've been added to our waitlist.",
        variant: "default"
      });
      form.reset();
      setIsSuccess(true);
      
      // Reset success message after 5 seconds
      setTimeout(() => setIsSuccess(false), 5000);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to join waitlist. Please try again.",
        variant: "destructive"
      });
    }
  });

  const onSubmit = (values: FormValues) => {
    waitlistMutation.mutate(values);
  };

  return (
    <div className="flex flex-col md:flex-row justify-between items-center">
      <div className="mb-4 md:mb-0">
        <h3 className="text-white text-xl font-serif font-bold">Join Our Exclusive Waitlist</h3>
        <p className="text-[#F5F5DC] text-sm">
          Be the first to access our new premium products and special offers.
        </p>
      </div>
      
      <Form {...form}>
        <form 
          onSubmit={form.handleSubmit(onSubmit)} 
          className="flex flex-col sm:flex-row w-full md:w-auto space-y-3 sm:space-y-0 sm:space-x-3"
        >
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem className="w-full md:w-64">
                <FormControl>
                  <Input
                    {...field}
                    placeholder="Your Email Address"
                    className="px-4 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-[#D4AF37] w-full"
                    disabled={waitlistMutation.isPending || isSuccess}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <Button 
            type="submit" 
            className="bg-[#D4AF37] hover:bg-[#F1C232] text-gray-900 px-6 py-2 rounded-md font-semibold transition duration-300"
            disabled={waitlistMutation.isPending || isSuccess}
          >
            {waitlistMutation.isPending 
              ? "Joining..." 
              : isSuccess 
                ? "Joined!" 
                : "Join Waitlist"}
          </Button>
        </form>
      </Form>
    </div>
  );
}
