import { Button } from "@/components/ui/button";
import { scrollToElement } from "@/lib/utils";
import WaitlistForm from "./waitlist-form";

interface HeroSectionProps {
  openQuoteModal: () => void;
}

export default function HeroSection({ openQuoteModal }: HeroSectionProps) {
  return (
    <section id="home" className="relative h-screen pt-16 bg-gray-900 overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1544025162-d76694265947?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80" 
          alt="Premium beef" 
          className="w-full h-full object-cover opacity-70"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-gray-900 to-transparent opacity-80"></div>
      </div>

      <div className="container relative z-10 mx-auto px-4 h-full flex flex-col justify-center">
        <div className="max-w-2xl">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-white leading-tight mb-4">
            Red Rock <span className="text-[#D4AF37]">Meats</span> <br />
            <span className="text-2xl md:text-3xl font-medium text-[#F5F5DC]">Premium Quality Since 1985</span>
          </h1>
          <p className="text-lg md:text-xl text-gray-100 mb-8 max-w-lg">
            From our ranches to your business. Delivering the finest quality beef cuts to markets around the globe.
          </p>
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
            <Button
              onClick={() => scrollToElement("products")}
              className="bg-[#8B0000] hover:bg-[#A52A2A] text-white px-6 py-3 rounded-md text-lg font-semibold transition duration-300 transform hover:scale-105"
              size="lg"
            >
              Explore Products
            </Button>
            <Button
              onClick={openQuoteModal}
              variant="outline"
              className="bg-transparent border-2 border-[#F5F5DC] hover:border-[#D4AF37] hover:text-[#D4AF37] text-[#F5F5DC] px-6 py-3 rounded-md text-lg font-semibold transition duration-300"
              size="lg"
            >
              Request a Quote
            </Button>
          </div>
        </div>
      </div>

      {/* Waitlist Signup Form */}
      <div className="absolute bottom-0 left-0 right-0 bg-gray-900 bg-opacity-90 py-6 px-4 md:px-0 border-t border-[#D4AF37] z-10">
        <div className="container mx-auto">
          <WaitlistForm />
        </div>
      </div>
    </section>
  );
}
