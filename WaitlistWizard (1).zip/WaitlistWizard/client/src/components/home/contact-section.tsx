import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { insertContactSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { MapPin, Phone, Mail, Clock } from "lucide-react";

// Extend the schema with additional validation
const formSchema = insertContactSchema.extend({
  email: z.string().email("Please enter a valid email address"),
  name: z.string().min(2, "Name must be at least 2 characters"),
  message: z.string().min(10, "Message must be at least 10 characters"),
});

type FormValues = z.infer<typeof formSchema>;

export default function ContactSection() {
  const { toast } = useToast();
  const [isSubmitted, setIsSubmitted] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      company: "",
      message: "",
      subscribe: false,
    },
  });

  const contactMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      const response = await apiRequest("POST", "/api/contact", values);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Message Sent",
        description: "Thank you for your message. We'll get back to you soon!",
        variant: "default"
      });
      form.reset();
      setIsSubmitted(true);
      
      // Reset form submitted state after 5 seconds
      setTimeout(() => setIsSubmitted(false), 5000);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send message. Please try again.",
        variant: "destructive"
      });
    }
  });

  const onSubmit = (values: FormValues) => {
    contactMutation.mutate(values);
  };

  return (
    <section id="contact" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-gray-900">
            Contact <span className="text-[#8B0000]">Us</span>
          </h2>
          <div className="w-24 h-1 bg-[#D4AF37] mx-auto my-4"></div>
          <p className="max-w-2xl mx-auto text-lg text-gray-600">
            Reach out to discuss how our premium beef products can meet your needs.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <h3 className="text-2xl font-serif font-bold text-[#613613] mb-6">Get In Touch</h3>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-700 font-medium">Full Name</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            className="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#8B0000]"
                            disabled={contactMutation.isPending || isSubmitted}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-700 font-medium">Email Address</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            type="email"
                            className="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#8B0000]"
                            disabled={contactMutation.isPending || isSubmitted}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="company"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700 font-medium">Company</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          className="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#8B0000]"
                          disabled={contactMutation.isPending || isSubmitted}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700 font-medium">Message</FormLabel>
                      <FormControl>
                        <Textarea 
                          {...field} 
                          rows={5}
                          className="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#8B0000]"
                          disabled={contactMutation.isPending || isSubmitted}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="subscribe"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          className="h-5 w-5 text-[#8B0000] border-gray-300 focus:ring-[#8B0000]"
                          disabled={contactMutation.isPending || isSubmitted}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel className="text-gray-700">
                          Subscribe to our newsletter for product updates
                        </FormLabel>
                      </div>
                    </FormItem>
                  )}
                />
                
                <Button
                  type="submit"
                  className="bg-[#8B0000] hover:bg-[#A52A2A] text-white px-8 py-3 rounded-md font-semibold transition duration-300 transform hover:scale-105 w-full md:w-auto"
                  disabled={contactMutation.isPending || isSubmitted}
                >
                  {contactMutation.isPending 
                    ? "Sending..." 
                    : isSubmitted 
                      ? "Message Sent!" 
                      : "Send Message"}
                </Button>
              </form>
            </Form>
          </div>
          
          <div>
            <h3 className="text-2xl font-serif font-bold text-[#613613] mb-6">Our Information</h3>
            
            <div className="bg-[#F5F5DC] p-8 rounded-lg">
              <div className="flex items-start mb-6">
                <MapPin className="text-[#8B0000] h-5 w-5 mr-4 mt-1" />
                <div>
                  <h4 className="font-bold text-gray-900 mb-1">Headquarters</h4>
                  <p className="text-gray-700">
                    1234 Premium Beef Road, <br />
                    Cattle Valley, TX 12345, <br />
                    United States
                  </p>
                </div>
              </div>
              
              <div className="flex items-start mb-6">
                <Phone className="text-[#8B0000] h-5 w-5 mr-4 mt-1" />
                <div>
                  <h4 className="font-bold text-gray-900 mb-1">Phone</h4>
                  <p className="text-gray-700">+1 (555) 123-4567</p>
                  <p className="text-gray-700">+1 (555) 765-4321</p>
                </div>
              </div>
              
              <div className="flex items-start mb-6">
                <Mail className="text-[#8B0000] h-5 w-5 mr-4 mt-1" />
                <div>
                  <h4 className="font-bold text-gray-900 mb-1">Email</h4>
                  <p className="text-gray-700">info@primebeef.com</p>
                  <p className="text-gray-700">exports@primebeef.com</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <Clock className="text-[#8B0000] h-5 w-5 mr-4 mt-1" />
                <div>
                  <h4 className="font-bold text-gray-900 mb-1">Business Hours</h4>
                  <p className="text-gray-700">Monday - Friday: 8:00 AM - 6:00 PM</p>
                  <p className="text-gray-700">Saturday: 9:00 AM - 1:00 PM</p>
                  <p className="text-gray-700">Sunday: Closed</p>
                </div>
              </div>
            </div>
            
            <div className="mt-8">
              <h4 className="font-bold text-gray-900 mb-4">Connect With Us</h4>
              <div className="flex space-x-4">
                <a href="#" className="bg-[#8B0000] text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#A52A2A] transition duration-300">
                  <i className="fab fa-facebook-f"></i>
                </a>
                <a href="#" className="bg-[#8B0000] text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#A52A2A] transition duration-300">
                  <i className="fab fa-twitter"></i>
                </a>
                <a href="#" className="bg-[#8B0000] text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#A52A2A] transition duration-300">
                  <i className="fab fa-linkedin-in"></i>
                </a>
                <a href="#" className="bg-[#8B0000] text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#A52A2A] transition duration-300">
                  <i className="fab fa-instagram"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
