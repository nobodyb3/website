import { processSteps } from "@/lib/data";

export default function ProcessSection() {
  return (
    <section className="py-20 bg-white overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-gray-900">
            Our <span className="text-[#8B0000]">Process</span>
          </h2>
          <div className="w-24 h-1 bg-[#D4AF37] mx-auto my-4"></div>
          <p className="max-w-2xl mx-auto text-lg text-gray-600">
            From ranch to distribution, we maintain the highest standards at every step.
          </p>
        </div>

        <div className="relative">
          {/* Process timeline line */}
          <div className="hidden md:block absolute left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-[#8B0000] to-[#613613] transform -translate-x-1/2 shadow-lg"></div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16">
            {processSteps.map((step, index) => {
              const isEven = index % 2 === 0;
              
              return (
                <div key={step.id} className={`${isEven ? "md:text-right md:pr-16" : "md:pl-16"} relative ${!isEven && index !== 0 ? "md:col-start-2" : ""} ${isEven && index !== 0 ? "md:hidden" : ""}`}>
                  {isEven ? (
                    <div className="hidden md:flex absolute right-0 top-6 w-12 h-12 rounded-full bg-[#8B0000] border-4 border-[#F5F5DC] text-white items-center justify-center font-bold transform translate-x-1/2">
                      {step.id}
                    </div>
                  ) : (
                    <div className="hidden md:flex absolute left-0 top-6 w-12 h-12 rounded-full bg-[#8B0000] border-4 border-[#F5F5DC] text-white items-center justify-center font-bold transform -translate-x-1/2">
                      {step.id}
                    </div>
                  )}
                  
                  <h3 className="text-2xl font-serif font-bold text-[#8B0000] mb-3">
                    {step.title}
                  </h3>
                  <p className="text-gray-700">
                    {step.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
