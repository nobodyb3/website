import { ranchImages } from "@/lib/data";

export default function AboutSection() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-gray-900">
            Our <span className="text-[#8B0000]">Heritage</span>
          </h2>
          <div className="w-24 h-1 bg-[#D4AF37] mx-auto my-4"></div>
          <p className="max-w-2xl mx-auto text-lg text-gray-600">
            Delivering premium quality beef from our family-owned ranches to markets around the world for over three generations.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="text-2xl font-serif font-semibold text-[#613613] mb-4">
              A Legacy of Excellence
            </h3>
            <p className="mb-4 text-gray-700">
              Founded in 1978, our company has been committed to delivering the highest quality beef products to our customers worldwide. Our family-owned ranches span thousands of acres of pristine grazing land, where our cattle are raised with care and attention.
            </p>
            <p className="mb-4 text-gray-700">
              We combine traditional ranching methods with modern processing techniques to ensure our beef maintains its exceptional quality from farm to table.
            </p>
            <div className="grid grid-cols-2 gap-4 mt-8">
              <div className="bg-[#F5F5DC] rounded-lg p-6 text-center">
                <span className="block text-3xl font-bold text-[#8B0000]">25+</span>
                <span className="text-[#613613] font-medium">Countries Served</span>
              </div>
              <div className="bg-[#F5F5DC] rounded-lg p-6 text-center">
                <span className="block text-3xl font-bold text-[#8B0000]">45+</span>
                <span className="text-[#613613] font-medium">Years Experience</span>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {ranchImages.map((image, index) => (
              <img 
                key={image.id}
                src={image.src} 
                alt={image.alt} 
                className={`rounded-lg shadow-lg object-cover h-64 ${index % 2 === 1 ? "mt-6" : ""}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
