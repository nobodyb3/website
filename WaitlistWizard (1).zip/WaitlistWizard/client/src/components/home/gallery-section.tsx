import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { galleryImages } from "@/lib/data";
import { X } from "lucide-react";

export default function GallerySection() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  return (
    <section className="py-20 bg-[#F5F5DC]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-gray-900">
            Product <span className="text-[#8B0000]">Gallery</span>
          </h2>
          <div className="w-24 h-1 bg-[#D4AF37] mx-auto my-4"></div>
          <p className="max-w-2xl mx-auto text-lg text-gray-600">
            A showcase of our premium beef products and facilities.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {galleryImages.map((image) => (
            <Dialog key={image.id}>
              <DialogTrigger asChild>
                <div className="relative overflow-hidden rounded-lg group h-48 md:h-64 cursor-pointer">
                  <img 
                    src={image.src} 
                    alt={image.alt} 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-[#8B0000] bg-opacity-0 group-hover:bg-opacity-40 transition duration-300 flex items-center justify-center">
                    <Button 
                      variant="secondary"
                      className="opacity-0 group-hover:opacity-100 bg-white text-[#8B0000] px-4 py-2 rounded-md transform translate-y-4 group-hover:translate-y-0 transition duration-300"
                    >
                      View Larger
                    </Button>
                  </div>
                </div>
              </DialogTrigger>
              <DialogContent className="max-w-4xl p-0 bg-transparent border-none">
                <div className="relative">
                  <img 
                    src={image.src} 
                    alt={image.alt} 
                    className="w-full h-auto rounded-lg"
                  />
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="absolute top-2 right-2 bg-black bg-opacity-50 text-white hover:bg-opacity-70 rounded-full p-1"
                    onClick={() => document.body.click()} // Close dialog
                  >
                    <X className="h-5 w-5" />
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          ))}
        </div>
      </div>
    </section>
  );
}
