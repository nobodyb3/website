import { Button } from "@/components/ui/button";
import { scrollToElement } from "@/lib/utils";
import { products } from "@/lib/data";

interface ProductsSectionProps {
  openQuoteModal: () => void;
}

export default function ProductsSection({ openQuoteModal }: ProductsSectionProps) {
  return (
    <section id="products" className="py-20 bg-[#F5F5DC]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-gray-900">
            Premium <span className="text-[#8B0000]">Products</span>
          </h2>
          <div className="w-24 h-1 bg-[#D4AF37] mx-auto my-4"></div>
          <p className="max-w-2xl mx-auto text-lg text-gray-600">
            Our selection of high-quality beef cuts, each carefully processed to preserve flavor and texture.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {products.map((product) => (
            <div 
              key={product.id} 
              className="bg-white/10 backdrop-blur-md rounded-lg overflow-hidden shadow-xl transition-all duration-300 transform hover:scale-105 hover:shadow-2xl border border-white/20 group"
            >
              <div className="relative h-60">
                <img 
                  src={product.imageSrc} 
                  alt={product.imageAlt} 
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-0 right-0 bg-[#8B0000] text-white px-3 py-1 font-medium">
                  {product.badge}
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-serif font-bold text-gray-900 mb-2">
                  {product.name}
                </h3>
                <p className="text-gray-600 mb-4">
                  {product.description}
                </p>
                <div className="flex justify-between items-center">
                  <span className="text-[#613613] font-semibold">Available for Export</span>
                  <Button 
                    onClick={openQuoteModal} 
                    className="bg-[#D4AF37] hover:bg-[#F1C232] text-gray-900 px-4 py-2 rounded-md font-medium transition duration-300"
                  >
                    Get Quote
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <Button 
            onClick={() => scrollToElement("contact")}
            className="bg-[#8B0000] hover:bg-[#A52A2A] text-white px-8 py-3 rounded-md text-lg font-semibold transition duration-300 transform hover:scale-105"
          >
            View All Products
          </Button>
        </div>
      </div>
    </section>
  );
}
