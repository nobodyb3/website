import { ReactNode, useState } from "react";
import Header from "./header";
import Footer from "./footer";
import QuoteModal from "@/components/home/quote-modal";

interface PageLayoutProps {
  children: ReactNode;
}

export default function PageLayout({ children }: PageLayoutProps) {
  const [quoteModalOpen, setQuoteModalOpen] = useState(false);

  const openQuoteModal = () => {
    setQuoteModalOpen(true);
  };

  const closeQuoteModal = () => {
    setQuoteModalOpen(false);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header openQuoteModal={openQuoteModal} />
      
      <main className="flex-grow pt-16 md:pt-20">
        {children}
      </main>
      
      <Footer />
      
      <QuoteModal 
        isOpen={quoteModalOpen} 
        onClose={closeQuoteModal} 
      />
    </div>
  );
}