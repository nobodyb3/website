import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { navItems } from "@/lib/data";
import { Link, useLocation } from "wouter";

interface HeaderProps {
  openQuoteModal: () => void;
}

export default function Header({ openQuoteModal }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <header className={cn(
      "fixed w-full bg-white z-50 transition-all duration-300",
      isScrolled ? "bg-opacity-95 shadow-md py-3" : "bg-opacity-90 py-4"
    )}>
      <div className="container mx-auto px-4 flex items-center justify-between">
        <div className="flex items-center">
          <Link href="/">
            <div className="text-[#8B0000] text-2xl font-bold tracking-tight font-serif cursor-pointer">
              <span className="text-[#613613]">Prime</span>Beef
            </div>
          </Link>
        </div>
        
        {/* Mobile menu button */}
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={toggleMobileMenu}
          className="md:hidden text-gray-800 hover:text-[#8B0000] focus:outline-none"
        >
          {mobileMenuOpen ? (
            <X className="h-6 w-6" />
          ) : (
            <Menu className="h-6 w-6" />
          )}
        </Button>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
            >
              <div className={cn(
                "text-gray-800 hover:text-[#8B0000] font-semibold transition duration-200 cursor-pointer",
                location === item.href && "text-[#8B0000] font-bold"
              )}>
                {item.name}
              </div>
            </Link>
          ))}
          <Button
            onClick={openQuoteModal}
            className="bg-[#8B0000] hover:bg-[#A52A2A] text-white px-4 py-2 rounded-md transition duration-300 transform hover:scale-105 font-semibold"
          >
            Get a Quote
          </Button>
        </nav>
      </div>
      
      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <nav className="px-4 py-3 bg-white border-t md:hidden">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
            >
              <div 
                className={cn(
                  "block py-2 text-gray-800 hover:text-[#8B0000] font-medium w-full text-left cursor-pointer",
                  location === item.href && "text-[#8B0000] font-bold"
                )}
                onClick={() => setMobileMenuOpen(false)}
              >
                {item.name}
              </div>
            </Link>
          ))}
          <Button
            onClick={() => {
              openQuoteModal();
              setMobileMenuOpen(false);
            }}
            className="mt-2 w-full bg-[#8B0000] hover:bg-[#A52A2A] text-white px-4 py-2 rounded-md transition duration-300"
          >
            Get a Quote
          </Button>
        </nav>
      )}
    </header>
  );
}
