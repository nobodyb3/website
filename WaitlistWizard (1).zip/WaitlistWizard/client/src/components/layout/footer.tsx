import { Facebook, Twitter, Linkedin, Instagram, MapPin, Phone, Mail, Clock } from "lucide-react";
import { navItems } from "@/lib/data";
import { scrollToElement } from "@/lib/utils";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <h3 className="text-xl font-serif font-bold mb-4">
              <span className="text-[#613613]">Prime</span>
              <span className="text-[#D4AF37]">Beef</span>
            </h3>
            <p className="text-gray-300 mb-4">
              Premium beef exports for discerning international markets.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-[#D4AF37] transition duration-300">
                <Facebook size={18} />
              </a>
              <a href="#" className="text-gray-300 hover:text-[#D4AF37] transition duration-300">
                <Twitter size={18} />
              </a>
              <a href="#" className="text-gray-300 hover:text-[#D4AF37] transition duration-300">
                <Linkedin size={18} />
              </a>
              <a href="#" className="text-gray-300 hover:text-[#D4AF37] transition duration-300">
                <Instagram size={18} />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              {navItems.map((item) => (
                <li key={item.href}>
                  <button 
                    onClick={() => scrollToElement(item.href)}
                    className="text-gray-300 hover:text-[#D4AF37] transition duration-300"
                  >
                    {item.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-4">Products</h4>
            <ul className="space-y-2">
              <li>
                <button 
                  onClick={() => scrollToElement("products")} 
                  className="text-gray-300 hover:text-[#D4AF37] transition duration-300"
                >
                  Premium Ribeye
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToElement("products")} 
                  className="text-gray-300 hover:text-[#D4AF37] transition duration-300"
                >
                  Tenderloin
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToElement("products")} 
                  className="text-gray-300 hover:text-[#D4AF37] transition duration-300"
                >
                  Strip Loin
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToElement("products")} 
                  className="text-gray-300 hover:text-[#D4AF37] transition duration-300"
                >
                  Tomahawk Steak
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToElement("products")} 
                  className="text-gray-300 hover:text-[#D4AF37] transition duration-300"
                >
                  View All Products
                </button>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-4">Contact Info</h4>
            <ul className="space-y-2">
              <li className="flex items-start">
                <MapPin className="text-[#D4AF37] h-5 w-5 mt-1 mr-3" />
                <span className="text-gray-300">1234 Premium Beef Road, Cattle Valley, TX 12345</span>
              </li>
              <li className="flex items-start">
                <Phone className="text-[#D4AF37] h-5 w-5 mt-1 mr-3" />
                <span className="text-gray-300">+1 (555) 123-4567</span>
              </li>
              <li className="flex items-start">
                <Mail className="text-[#D4AF37] h-5 w-5 mt-1 mr-3" />
                <span className="text-gray-300">info@primebeef.com</span>
              </li>
              <li className="flex items-start">
                <Clock className="text-[#D4AF37] h-5 w-5 mt-1 mr-3" />
                <div className="text-gray-300">
                  <p>Monday - Friday: 8:00 AM - 6:00 PM</p>
                  <p>Saturday: 9:00 AM - 1:00 PM</p>
                  <p>Sunday: Closed</p>
                </div>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-10 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} PrimeBeef Exports. All rights reserved.
          </p>
          <div className="flex space-x-6">
            <a href="#" className="text-gray-400 hover:text-[#D4AF37] text-sm transition duration-300">
              Privacy Policy
            </a>
            <a href="#" className="text-gray-400 hover:text-[#D4AF37] text-sm transition duration-300">
              Terms of Service
            </a>
            <a href="#" className="text-gray-400 hover:text-[#D4AF37] text-sm transition duration-300">
              Sitemap
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
