// Navigation items
export const navItems = [
  { name: "Home", href: "/" },
  { name: "About", href: "/about" },
  { name: "Products", href: "/products" },
  { name: "Process", href: "/process" },
  { name: "Gallery", href: "/gallery" },
  { name: "Contact", href: "/contact" }
];

// Product data
export const products = [
  {
    id: 1,
    name: "Ribeye Steak",
    description: "Exceptionally marbled premium ribeye, aged to perfection for optimal flavor and tenderness.",
    imageSrc: "https://images.unsplash.com/photo-1603360946369-dc9bb6258143?ixlib=rb-1.2.1&auto=format&fit=crop&w=900&q=80",
    imageAlt: "Premium ribeye steak",
    badge: "Premium"
  },
  {
    id: 2,
    name: "Tenderloin",
    description: "The most tender cut of beef with subtle flavor, ideal for upscale dining establishments.",
    imageSrc: "https://images.unsplash.com/photo-1588168333986-5078d3ae3976?ixlib=rb-1.2.1&auto=format&fit=crop&w=900&q=80",
    imageAlt: "Tenderloin premium cut",
    badge: "Premium"
  },
  {
    id: 3,
    name: "Strip Loin",
    description: "Well-marbled with a firm texture and robust beef flavor, perfect for high-end restaurants.",
    imageSrc: "https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?ixlib=rb-1.2.1&auto=format&fit=crop&w=900&q=80",
    imageAlt: "Premium strip loin",
    badge: "Premium"
  }
];

// Process steps
export const processSteps = [
  {
    id: 1,
    title: "Premium Cattle Breeding",
    description: "Our cattle are selectively bred for quality, raised on open pastures with natural feed to ensure premium meat characteristics."
  },
  {
    id: 2,
    title: "Ethical Farming Practices",
    description: "We maintain the highest standards of animal welfare, ensuring our cattle live stress-free lives in a natural environment."
  },
  {
    id: 3,
    title: "State-of-the-Art Processing",
    description: "Our HACCP-certified facilities use advanced technology to process beef under strict quality control measures."
  },
  {
    id: 4,
    title: "Global Distribution",
    description: "Our temperature-controlled logistics ensure products maintain perfect quality during shipping to markets worldwide."
  }
];

// Features/Why Choose Us
export const features = [
  {
    id: 1,
    title: "Superior Quality",
    description: "Our selective breeding and premium feeding programs result in consistently exceptional beef quality.",
    icon: "award"
  },
  {
    id: 2,
    title: "Certified Standards",
    description: "Our facilities meet international certification standards for food safety and quality management.",
    icon: "certificate"
  },
  {
    id: 3,
    title: "Global Shipping",
    description: "Our temperature-controlled logistics ensure product integrity during international transport.",
    icon: "truck"
  },
  {
    id: 4,
    title: "Reliable Partnership",
    description: "We maintain long-term relationships with customers, providing consistent supply and support.",
    icon: "handshake"
  }
];

// Gallery images
export const galleryImages = [
  {
    id: 1,
    src: "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?ixlib=rb-1.2.1&auto=format&fit=crop&w=900&q=80",
    alt: "Premium beef cut"
  },
  {
    id: 2,
    src: "https://images.unsplash.com/photo-1615937657715-bc7b4b7962c1?ixlib=rb-1.2.1&auto=format&fit=crop&w=900&q=80",
    alt: "T-bone steak"
  },
  {
    id: 3,
    src: "https://images.unsplash.com/photo-1560781290-7dc94c0f8f4f?ixlib=rb-1.2.1&auto=format&fit=crop&w=900&q=80",
    alt: "Processing facility"
  },
  {
    id: 4,
    src: "https://images.unsplash.com/photo-1551028150-64b9f398f678?ixlib=rb-1.2.1&auto=format&fit=crop&w=900&q=80",
    alt: "Cattle ranch"
  },
  {
    id: 5,
    src: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?ixlib=rb-1.2.1&auto=format&fit=crop&w=900&q=80",
    alt: "Cooked steak"
  },
  {
    id: 6,
    src: "https://images.unsplash.com/photo-1527443154391-507e9dc6c5cc?ixlib=rb-1.2.1&auto=format&fit=crop&w=900&q=80",
    alt: "Shipping facility"
  },
  {
    id: 7,
    src: "https://images.unsplash.com/photo-1592686092916-672fa9e86866?ixlib=rb-1.2.1&auto=format&fit=crop&w=900&q=80",
    alt: "Premium cut display"
  },
  {
    id: 8,
    src: "https://images.unsplash.com/photo-1575222232444-b45ea30749fc?ixlib=rb-1.2.1&auto=format&fit=crop&w=900&q=80",
    alt: "Cattle grazing"
  }
];

// Product info for the quote form
export const productOptions = [
  { value: "", label: "Select a product" },
  { value: "ribeye", label: "Premium Ribeye" },
  { value: "tenderloin", label: "Tenderloin" },
  { value: "striploin", label: "Strip Loin" },
  { value: "tomahawk", label: "Tomahawk Steak" },
  { value: "brisket", label: "Brisket" },
  { value: "shortrib", label: "Short Ribs" },
  { value: "other", label: "Other" }
];

// About section ranch images
export const ranchImages = [
  {
    id: 1,
    src: "https://images.unsplash.com/photo-1575881875475-31023242e3f9?ixlib=rb-1.2.1&auto=format&fit=crop&w=900&q=80",
    alt: "Cattle ranch landscape"
  },
  {
    id: 2,
    src: "https://images.unsplash.com/photo-1516460140987-2c1bf1f8c49f?ixlib=rb-1.2.1&auto=format&fit=crop&w=900&q=80",
    alt: "Cattle grazing"
  },
  {
    id: 3,
    src: "https://images.unsplash.com/photo-1460572894071-bde5697f7197?ixlib=rb-1.2.1&auto=format&fit=crop&w=900&q=80",
    alt: "Ranch worker"
  },
  {
    id: 4,
    src: "https://images.unsplash.com/photo-1560355206-7bdbaa14a9c9?ixlib=rb-1.2.1&auto=format&fit=crop&w=900&q=80",
    alt: "Cattle herd"
  }
];
